package com.rmalmeidax.Lista.Mercado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplicativoListaMercadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
