package com.rmalmeidax.Lista.Mercado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplicativoListaMercadoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplicativoListaMercadoApplication.class, args);
	}

}
